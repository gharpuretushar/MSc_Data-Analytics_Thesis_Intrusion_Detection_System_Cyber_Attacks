from flask import Flask, render_template, jsonify
import pandas as pd
import numpy as np
import joblib
from tensorflow.keras.models import load_model
import time

app = Flask(__name__)

model = load_model("model/conv_lstm_model.keras")
scaler = joblib.load("model/scaler.pkl")
data = pd.read_csv("input/X_test_for_prediction.csv")

if 'target' in data.columns:
    data = data.drop(columns=['target'])

row_index = [0]
label_map = {
    0: "Benign",
    1: "DoS",
    2: "DDoS",
    3: "BruteForce",
    4: "Scan",
    5: "Web-based"
}
stats = {"Benign": 0, "DoS": 0, "DDoS": 0, "BruteForce": 0, "Scan": 0, "Web-based": 0}

def predict_row(row_array):
    scaled = scaler.transform(row_array.reshape(1, -1))
    timesteps = 4
    feature_dim = scaled.shape[1] // timesteps
    reshaped = scaled[:, :timesteps * feature_dim].reshape(1, timesteps, feature_dim, 1)
    pred = model.predict(reshaped)
    label_id = np.argmax(pred, axis=1)[0]
    label = label_map.get(label_id, "Unknown")
    prob = float(pred[0][label_id])
    return label, prob

@app.route('/')
def dashboard():
    return render_template("index.html")

@app.route('/predict')
def get_prediction():
    if row_index[0] >= len(data):
        return jsonify({"end": True})

    row = data.iloc[row_index[0]].values.astype(np.float64)
    label, confidence = predict_row(row)

    stats[label] += 1
    current_row = row_index[0] + 1
    row_index[0] += 1

    return jsonify({
        "row": current_row,
        "label": label,
        "confidence": f"{confidence*100:.2f}%",
        "stats": stats
    })

if __name__ == '__main__':
    app.run(debug=True)
