# To run the application 
python app.py

# To check the web application on browser 
http://127.0.0.1:5000/
